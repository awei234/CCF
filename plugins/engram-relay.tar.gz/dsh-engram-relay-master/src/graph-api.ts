/**
 * installGraphApi — engram 记忆图谱 Web API（host 侧）。
 *
 * 供 web client「图谱」Tab 消费：按查看者视角（sessionId → cwd）做**分层
 * 准入**后返回节点 + 边（因果边 + 双向链接边），以及单节点详情（渐进披露
 * 第二层：正文/因果/链接）。
 *
 * 路由（prefix /engram-relay/api）：
 *  - GET /graph?sessionId=…        → { nodes, edges, layerCounts, total }
 *  - GET /node/<title>?sessionId=… → 节点详情（content + 前因/后果/关联）
 *
 * 可见性边界与唤醒/工具一致：global 所有会话 / project 同 cwd / session 本会话。
 */

import type { Context as CordisContext } from 'cordis'
import { appendFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

import { isVisible, isSuperseded, type EngramNode } from './engram/store.js'
import type { EngramRelay } from './relay.js'

type HttpCtx = CordisContext & {
  webServer: {
    register(route: {
      kind: string
      path: string
      handler: (req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse) => Promise<void> | void
    }): () => void
  }
}

/** 发送 JSON 响应。 */
function sendJson(res: import('node:http').ServerResponse, status: number, body: unknown): void {
  const text = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(text)
}

/** 从请求 query 解析查看者视角：sessionId → cwd（agents 服务解析会话工作目录）。 */
function resolveViewer(ctx: CordisContext, url: URL, relay: EngramRelay): { sessionId?: string; cwd?: string } {
  const sessionId = url.searchParams.get('sessionId') ?? undefined
  const agents = ctx.get('agents') as { get?: (id: string) => { session?: { header?: { cwd?: string } } } } | undefined
  let cwd = sessionId !== undefined
    ? agents?.get?.(sessionId)?.session?.header?.cwd
    : undefined
  // 兜底：agents 表查不到该会话（已归档/非活跃/服务未暴露）时，回退到
  // relay 持续追踪的当前工作目录——web 图谱 Tab 服务当前活动会话，
  // 这样 project 层记忆仍然可见，不会只剩 global 一个点。
  if (cwd === undefined && sessionId !== undefined) {
    cwd = relay.currentCwd ?? undefined
  }
  // 最终兜底：store 里最近写入的 project 层节点所属项目（HMR 后
  // currentCwd 可能尚未捕获；web 图谱面向「当前/最近项目」的记忆网络）。
  if (cwd === undefined && sessionId !== undefined) {
    const recent = relay.store.query({ layer: 'project', limit: 1, recent: true })
    cwd = recent[0]?.projectId ?? undefined
  }
  return { sessionId, cwd }
}

/** 节点视图（图谱渲染最小集）。 */
function nodeView(n: EngramNode) {
  return {
    id: n.id,
    title: n.title,
    summary: n.summary,
    kind: n.kind,
    layer: n.layer,
    projectId: n.projectId,
    importance: n.importance,
    hits: n.hits,
    createdAt: n.createdAt,
    state: n.state ?? 'episodic',
  }
}

/** 边视图。 */
interface EdgeView { from: string; to: string; kind: 'causes' | 'link' }

export function installGraphApi(ctx: HttpCtx, relay: EngramRelay): () => void {
  return ctx.webServer.register({
    kind: 'prefix',
    path: '/engram-relay/api',
    handler: async (req, res) => {
      const url = new URL(req.url ?? '/', 'http://localhost')
      const viewer = resolveViewer(ctx, url, relay)

      // GET /graph：当前有效节点 + 边（v0.6：**过滤废止旧版、待确认与
      // 工作快照**——快照是过程性工作状态（非知识），其 links 曾制造巨型
      // 连通分量（89% 节点串成一个大圆）；知识图谱只显示知识节点）
      if (req.method === 'GET' && url.pathname === '/engram-relay/api/graph') {
        const visible = relay.store.all().filter((n) => isVisible(n, viewer) && !isSuperseded(n) && n.status !== 'pending' && n.kind !== 'snapshot')
        const ids = new Set(visible.map((n) => n.id))
        const edges: EdgeView[] = []
        const seen = new Set<string>()
        const addEdge = (from: string, to: string, kind: EdgeView['kind']): void => {
          const key = `${from}|${to}|${kind}`
          if (seen.has(key)) return
          seen.add(key)
          edges.push({ from, to, kind })
        }
        for (const n of visible) {
          // 因果边（前因/后果双向展开）
          for (const c of n.causes) if (ids.has(c)) addEdge(c, n.id, 'causes')
          for (const e of n.effects) if (ids.has(e)) addEdge(n.id, e, 'causes')
          // 双向链接边（Obsidian 风格 [[标题]]）
          for (const l of n.links) {
            const t = relay.store.byTitle(l)
            if (t && ids.has(t.id) && t.id !== n.id) addEdge(n.id, t.id, 'link')
          }
        }
        sendJson(res, 200, {
          nodes: visible.map(nodeView),
          edges,
          layerCounts: relay.store.layerCounts(),
          total: visible.length,
          viewer,
        })
        return
      }

      // POST /graph-log：浏览器运行时自检日志（项目圆重叠等——宿主可读，
      // 不再靠用户描述猜）
      if (req.method === 'POST' && url.pathname === '/engram-relay/api/graph-log') {
        let body = ''
        for await (const chunk of req) body += String(chunk)
        try {
          appendFileSync(join(homedir(), '.dsh', 'super-injector', 'engram-graph.log'), body)
        } catch { /* 日志写失败不阻塞 */ }
        sendJson(res, 200, { ok: true })
        return
      }

      // GET /node/<title>：节点详情（渐进披露第二层）
      const match = /^\/engram-relay\/api\/node\/(.+)$/.exec(url.pathname)
      if (req.method === 'GET' && match !== null) {
        const title = decodeURIComponent(match[1]).replace(/^\[\[|\]\]$/g, '')
        const node = relay.store.byTitle(title)
        if (!node) {
          sendJson(res, 404, { error: `node not found: ${title}` })
          return
        }
        // v0.4：全可见（项目不隔离）——无 403 分支
        relay.store.touch(node.id)
        sendJson(res, 200, {
          ...nodeView(node),
          content: node.content,
          causes: relay.store.getMany(node.causes).map((c) => nodeView(c)),
          effects: relay.store.getMany(node.effects).map((e) => nodeView(e)),
          links: node.links.map((t) => {
            const target = relay.store.byTitle(t)
            return target ? nodeView(target) : { id: '', title: t, summary: '', kind: 'note', layer: 'global', projectId: null, importance: 0, hits: 0, createdAt: 0, state: 'episodic' }
          }),
        })
        return
      }

      sendJson(res, 404, { error: 'not found' })
    },
  })
}
